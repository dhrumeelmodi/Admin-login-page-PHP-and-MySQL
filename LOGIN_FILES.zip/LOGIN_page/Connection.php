<?php 

$con=mysqli_connect("localhost","root","","admin_database");

if(mysqli_connect_error()){
    echo"Cannot connect to database";
}
// else{
//     echo"Connection established to database successfully";
// }


?>